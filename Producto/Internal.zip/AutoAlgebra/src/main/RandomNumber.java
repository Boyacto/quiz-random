/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main;
import java.util.Random;
import java.util.Vector;
import main.PreguntaDAO; 
/**
 *
 * @author elcon
 */
public class RandomNumber {
    public static void main(String args[]){
        PreguntaDAO dao = new PreguntaDAO();
        Vector vect = dao.getMemberList();
        System.out.println(vect.size());
    }
    public int Randompregunta() {
        int r_pregunta = 0; //int형 배열 선언
        PreguntaDAO dao = new PreguntaDAO();
        Vector vect = dao.getMemberList();
        Random r = new Random();
        r_pregunta = r.nextInt(vect.size())+1;
        
        return r_pregunta;
    }
}
