/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

/**
 *
 * @author elcon
 */
public class PreguntaDTO {

    int id_pregunta;
    String pregunta;
    String respuesta;
    String puntaje;
    String r_falsa1;
    String r_falsa2;
    String r_falsa3;

    public int getId() {
        return id_pregunta;
    }
    public void setId(int id_pregunta) {
        this.id_pregunta = id_pregunta;
    }
    public String getPr() {
        return pregunta;
    }
    public void setPr(String pregunta) {
        this.pregunta = pregunta;
    }
    public String getRe() {
        return respuesta;
    }
    public void setRe(String respuesta) {
        this.respuesta = respuesta;
    }
    public String getPt() {
        return puntaje;
    }
    public void setPt(String puntaje) {
        this.puntaje = puntaje;
    }
    public String getRf1() {
        return r_falsa1;
    }
    public void setRf1(String r_falsa1) {
        this.r_falsa1 = r_falsa1;
    }
    public String getRf2() {
        return r_falsa1;
    }
    public void setRf2(String r_falsa2) {
        this.r_falsa2 = r_falsa2;
    }
    public String getRf3() {
        return r_falsa3;
    }
    public void setRf3(String r_falsa3) {
        this.r_falsa3 = r_falsa3;
    }
    @Override
    public String toString() {
        return "PreguntaDTO [id_pregunta=" + id_pregunta + ", pregunta=" + pregunta + ", respuesta=" + respuesta
                + ", puntaje=" + puntaje + ", r_falsa1=" + r_falsa1 + ", r_falsa2=" + r_falsa2
                + ", r_falsa3=" + r_falsa3 + "]";
    }
}