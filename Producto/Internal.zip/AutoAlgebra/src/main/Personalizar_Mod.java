package main;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import main.PreguntaDTO;
import main.PreguntaDAO;
import java.awt.*;
import java.sql.*;
import java.util.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.*;
import static javax.swing.WindowConstants.DISPOSE_ON_CLOSE;
 
public class Personalizar_Mod extends JFrame implements ActionListener {
   
   
    JPanel p;
    JTextField tfId;
    JTextArea taPr, taRe, taPt, taRf1, taRf2, taRf3;
    JButton btnInsert, btnCancelar, btnActualizar,btnBorrar; //가입, 취소, 수정 , 탈퇴 버튼
   
    GridBagLayout gb;
    GridBagConstraints gbc;
    Examen_Personalizar pList ;
   
    public Personalizar_Mod(){ //가입용 생성자
       
        createUI(); // UI작성해주는 메소드
        btnActualizar.setEnabled(false);
        btnActualizar.setVisible(false);
        btnBorrar.setEnabled(false);
        btnBorrar.setVisible(false);
       
       
    }//생성자
   
    public Personalizar_Mod(Examen_Personalizar pList){ //가입용 생성자
       
        createUI(); // UI작성해주는 메소드
        btnActualizar.setEnabled(false);
        btnActualizar.setVisible(false);
        btnBorrar.setEnabled(false);
        btnBorrar.setVisible(false);
        this.pList = pList;
       
    }//생성자
    public Personalizar_Mod(int id_pregunta,Examen_Personalizar pList){ // 수정/삭제용 생성자
        createUI();
        btnInsert.setEnabled(false);
        btnInsert.setVisible(false);
        this.pList = pList;
       
       
        System.out.println("id="+id_pregunta);
       
        PreguntaDAO dao = new PreguntaDAO();
        PreguntaDTO vPre = dao.getMemberDTO(id_pregunta);
        viewData(vPre);
       
       
    }//id를 가지고 생성
 
       
    //MemberDTO 의 회원 정보를 가지고 화면에 셋팅해주는 메소드
    private void viewData(PreguntaDTO vPre){
       
        int id_pregunta = vPre.getId();
        String pregunta = vPre.getPr();
        String respuesta = vPre.getRe();
        String puntaje = vPre.getPt();
        String r_falsa1 = vPre.getRf1();
        String r_falsa2 = vPre.getRf2();
        String r_falsa3 = vPre.getRf3();
    
       
        //화면에 세팅
        tfId.setText(String.valueOf(id_pregunta));
        tfId.setEditable(false); //편집 안되게
        taPr.setText(pregunta);
        taRe.setText(respuesta);
        taPt.setText(puntaje);
        taRf1.setText(r_falsa1);
        taRf2.setText(r_falsa2);
        taRf3.setText(r_falsa3);      
    }//viewData
   
   
   
    private void createUI(){
        this.setTitle("Pregunta");
        gb = new GridBagLayout();
        setLayout(gb);
        gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.BOTH;
        gbc.weightx = 1.0;
        gbc.weighty = 1.0;
       
       
        //아이디
        JLabel bId = new JLabel("Id_pregunta : ");
        tfId = new JTextField(20);     
        //그리드백에 붙이기
        gbAdd(bId, 0, 0, 1, 1);
        gbAdd(tfId, 1, 0, 3, 1);
       
        JLabel bPr = new JLabel("Pregunta: ");
        taPr = new JTextArea(5, 20); //행 : 열
        JScrollPane pane1 = new JScrollPane(taPr);
        gbAdd(bPr,0,1,1,1);
        gbAdd(pane1,1,1,3,1);

        JLabel bRe = new JLabel("Respuesta: ");
        taRe = new JTextArea(5, 20); //행 : 열
        JScrollPane pane2 = new JScrollPane(taRe);
        gbAdd(bRe,0,2,1,1);
        gbAdd(pane2,1,2,3,1);

        JLabel bPt = new JLabel("Puntaje: ");
        taPt = new JTextArea(5, 20); //행 : 열
        JScrollPane pane3 = new JScrollPane(taPt);
        gbAdd(bPt,0,3,1,1);
        gbAdd(pane3,1,3,3,1);

        JLabel bRf = new JLabel("Respuesta falsa: ");
        taRf1 = new JTextArea(5, 20); //행 : 열
        JScrollPane pane4 = new JScrollPane(taRf1);
        gbAdd(bRf,0,4,1,1);
        gbAdd(pane4,1,4,3,1);
        taRf2 = new JTextArea(5, 20); //행 : 열
        JScrollPane pane5 = new JScrollPane(taRf2);
        gbAdd(pane5,1,5,3,1);
        taRf3 = new JTextArea(5, 20); //행 : 열
        JScrollPane pane6 = new JScrollPane(taRf3);
        gbAdd(pane6,1,5,3,1);        
        //버튼
        JPanel pButton = new JPanel();
        btnInsert = new JButton("Agregar");
        btnActualizar = new JButton("Modificar"); 
        btnBorrar = new JButton("Borrar");
        btnCancelar = new JButton("Cancelar");     
        pButton.add(btnInsert);
        pButton.add(btnActualizar);
        pButton.add(btnBorrar);
        pButton.add(btnCancelar);    
        gbAdd(pButton, 0, 10, 4, 1);
       
        //버튼에 감지기를 붙이자
        btnInsert.addActionListener(this);
        btnActualizar.addActionListener(this);
        btnCancelar.addActionListener(this);
        btnBorrar.addActionListener(this);
       
        setSize(350,500);
        setVisible(true);
        //setDefaultCloseOperation(EXIT_ON_CLOSE); //System.exit(0) //프로그램종료
        setDefaultCloseOperation(DISPOSE_ON_CLOSE); //dispose(); //현재창만 닫는다.
       
       
    }//createUI
   
    //그리드백레이아웃에 붙이는 메소드
    private void gbAdd(JComponent c, int x, int y, int w, int h){
        gbc.gridx = x;
        gbc.gridy = y;
        gbc.gridwidth = w;
        gbc.gridheight = h;
        gb.setConstraints(c, gbc);
        gbc.insets = new Insets(2, 2, 2, 2);
        add(c, gbc);
    }//gbAdd
   
    public static void main(String[] args) {
       
        new Personalizar_Mod();
    }
   
 
    @Override
    public void actionPerformed(ActionEvent ae) {
        if(ae.getSource() == btnInsert){
            insertMember();
            System.out.println("insertMember() stop calling");
        }else if(ae.getSource() == btnCancelar){
            this.dispose(); //창닫기 (현재창만 닫힘)
            //system.exit(0)=> 내가 띄운 모든 창이 다 닫힘          
        }else if(ae.getSource() == btnActualizar){
            UpdateMember();            
        }else if(ae.getSource() == btnBorrar){
            //int x = JOptionPane.showConfirmDialog(this,"정말 삭제하시겠습니까?");
            int x = JOptionPane.showConfirmDialog(this,"Realmente quieres borrar?","borrar",JOptionPane.YES_NO_OPTION);
           
            if (x == JOptionPane.OK_OPTION){
                deleteMember();
            }else{
                JOptionPane.showMessageDialog(this, "Canceló borrar.");
            }
        }
       
        //jTable내용 갱신 메소드 호출
        pList.jTableRefresh();
       
    }//actionPerformed 
   
   
    private void deleteMember() {
        int id_pregunta = Integer.parseInt(tfId.getText());

        //System.out.println(mList);
        PreguntaDAO dao = new PreguntaDAO();
        boolean ok = dao.deleteMember(id_pregunta);
       
        if(ok){
            JOptionPane.showMessageDialog(this, "Borrado completamente");
            dispose();         
           
        }else{
            JOptionPane.showMessageDialog(this, "No logró borrar");
           
        }          
       
    }//deleteMember
   
    private void UpdateMember() {
       
        //1. pantalla 
        PreguntaDTO dto = getViewData();     
        //2. 그정보로 DB를 수정
        PreguntaDAO dao = new PreguntaDAO();
        boolean ok = dao.updateMember(dto);
       
        if(ok){
            JOptionPane.showMessageDialog(this, "Corregido.");
            this.dispose();
        }else{
            JOptionPane.showMessageDialog(this, "No logró corregir: revise los variables");   
        }
    }
 
    private void insertMember(){
       
        //화면에서 사용자가 입력한 내용을 얻는다.
        PreguntaDTO dto = getViewData();
        PreguntaDAO dao = new PreguntaDAO();       
        boolean ok = dao.insertMember(dto);
       
        if(ok){
           
            JOptionPane.showMessageDialog(this, "Agregado satisfactoriamente.");
            dispose();
           
        }else{
           
            JOptionPane.showMessageDialog(this, "No logró agregar, error.");
        }
       
       
       
    }//insertMember
   
    public PreguntaDTO getViewData(){
       
        //화면에서 사용자가 입력한 내용을 얻는다.
        PreguntaDTO dto = new PreguntaDTO();
        int id_pregunta =Integer.parseInt(tfId.getText());
        String pregunta = taPr.getText();
        String respuesta = taRe.getText();
        String puntaje = taPt.getText();
        String r_falsa1 = taRf1.getText();
        String r_falsa2 = taRf2.getText();
        String r_falsa3 = taRf3.getText();
    //dto에 담는다.
        dto.setId(id_pregunta);
        dto.setPr(pregunta);
        dto.setRe(respuesta);
        dto.setPt(puntaje);
        dto.setRf1(r_falsa1);
        dto.setRf2(r_falsa2);
        dto.setRf3(r_falsa3);
        
        return dto;
    }
   
}//end/*

