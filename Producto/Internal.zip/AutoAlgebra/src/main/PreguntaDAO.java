package main;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

//이름 규칙 : 테이블명DAO , 테이블명DTO
//CRUD : Create;insert , Read;Select, Update, delete
 
import java.sql.*;
import java.util.Vector;
 import javax.swing.table.DefaultTableModel;
 
//DB 처리
public class PreguntaDAO {
 
    private static final String DRIVER
        = "com.mysql.jdbc.Driver";
    private static final String URL
        = "jdbc:mysql://localhost/test";
   
    private static final String USER = "root"; //DB ID
    private static final String PASS = ""; //DB contra
    Examen_Personalizar pList;
   
    public PreguntaDAO(Examen_Personalizar pList){
        this.pList = pList;
        System.out.println("DAO=>"+pList);
    }

    PreguntaDAO() {
    }
   
    /**DB연결 메소드*/
    public Connection getConn(){
        Connection con = null;
       
        try {
            Class.forName(DRIVER); //1. 드라이버 로딩
            con = DriverManager.getConnection(URL,USER,PASS); //2. 드라이버 연결
           
        } catch (Exception e) {
            e.printStackTrace();
        }
       
        return con;
    }
   
   
    /**Método para recibir datos de una pregunta*/
    public PreguntaDTO getMemberDTO(int id_pregunta){
       
        PreguntaDTO dto = new PreguntaDTO();
       
        Connection con = null;       //concección
        PreparedStatement ps = null; //dar orden
        ResultSet rs = null;         //resultado
       
        try {
           
            con = getConn();
            String sql = "select * from pregunta where id_pregunta=?";
            ps = con.prepareStatement(sql);
            ps.setInt(1, id_pregunta);
           
            rs = ps.executeQuery();
           
            if(rs.next()){
                dto.setId(rs.getInt("id_pregunta"));
                dto.setPr(rs.getString("pregunta"));
                dto.setRe(rs.getString("respuesta"));
                dto.setPt(rs.getString("puntaje"));
                dto.setRf1(rs.getString("r_falsa1"));
                dto.setRf2(rs.getString("r_falsa2"));
                dto.setRf3(rs.getString("r_falsa3"));
               
            }
        } catch (Exception e) {
            e.printStackTrace();
        }      
       
        return dto;    
    }
   
    /**멤버리스트 출력*/
    public Vector getMemberList(){
       
        Vector data = new Vector();  //Jtable에 값을 쉽게 넣는 방법 1. 2차원배열   2. Vector 에 vector추가
       
           
        Connection con = null;       //연결
        PreparedStatement ps = null; //명령
        ResultSet rs = null;         //결과
       
        try{
           
            con = getConn();
            //String sql = "select * from pregunta order by name asc";
            String sql = "select * from pregunta";
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
           
            while(rs.next()){
                int id_pregunta = rs.getInt("id_pregunta");
                String pregunta = rs.getString("pregunta");
                String respuesta = rs.getString("respuesta");
                String puntaje = rs.getString("puntaje");
                String r_falsa1 = rs.getString("r_falsa1");
                String r_falsa2 = rs.getString("r_falsa2");
                String r_falsa3 = rs.getString("r_falsa3");

               
                Vector row = new Vector();
                row.add(id_pregunta);
                row.add(pregunta);
                row.add(respuesta);
                row.add(puntaje);
                row.add(r_falsa1);
                row.add(r_falsa2);
                row.add(r_falsa3);
               
                data.add(row);             
            }//while
        }catch(Exception e){
            e.printStackTrace();
        }
        return data;
    }//getMemberList()
   
 
 
    /**회원 등록*/
    public boolean insertMember(PreguntaDTO dto){
       
        boolean ok = false;
       
        Connection con = null;       //연결
        PreparedStatement ps = null; //명령
       
        try{
           
            con = getConn();
            String sql = "insert into pregunta(" +
                        "id_pregunta,pregunta,respuesta,puntaje,r_falsa1,r_falsa2," +
                        "r_falsa3) "+
                        "values(?,?,?,?,?,?,?)";
           
            ps = con.prepareStatement(sql);
            ps.setInt(1, dto.getId());
            ps.setString(2, dto.getPr());
            ps.setString(3, dto.getRe());
            ps.setString(4, dto.getPt());
            ps.setString(5, dto.getRf1());
            ps.setString(6, dto.getRf2());
            ps.setString(7, dto.getRf3());          
            int r = ps.executeUpdate(); //실행 -> 저장
           
           
            if(r>0){
                System.out.println("pregunta agregada");   
                ok=true;
            }else{
                System.out.println("fallo en el sistema, introduzca todas las variables");
            }
           
               
           
        }catch(Exception e){
            e.printStackTrace();
        }
       
        return ok;
    }//insertMmeber
   
   
    /**회원정보 수정*/
    public boolean updateMember(PreguntaDTO vPre){
        System.out.println("dto="+vPre.toString());
        boolean ok = false;
        Connection con = null;
        PreparedStatement ps = null;
        try{
            con = getConn();           
            String sql = "update pregunta set pregunta=?, respuesta=?, puntaje=?, r_falsa1=?, r_falsa2=?, r_falsa3=?" +
                     " where id_pregunta=?";
           
            ps = con.prepareStatement(sql);
           
            
            ps.setString(1, vPre.getPr());
            ps.setString(2, vPre.getRe());
            ps.setString(3, vPre.getPt());
            ps.setString(4, vPre.getRf1());
            ps.setString(5, vPre.getRf2());
            ps.setString(6, vPre.getRf3());
            ps.setInt(7, vPre.getId());
            int r = ps.executeUpdate(); //실행 -> 수정
            // 1~n: 성공 , 0 : 실패
           
            if(r>0) ok = true; //수정이 성공되면 ok값을 true로 변경
           
        }catch(Exception e){
            e.printStackTrace();
        }
       
        return ok;
    }
   
    //no se si esta bien hacer esto
    public boolean deleteMember(int id_pregunta){
       
        boolean ok =false ;
        Connection con =null;
        PreparedStatement ps =null;
       
        try {
            con = getConn();
            String sql = "delete from pregunta where id_pregunta=?";
           
            ps = con.prepareStatement(sql);
            ps.setInt(1, id_pregunta);
            int r = ps.executeUpdate(); // 실행 -> 삭제           
            if (r>0) ok=true; //삭제됨;
           
        } catch (Exception e) {
            System.out.println(e + "-> Error ocurrido");
        }      
        return ok;
    }
   
   
    /**DB데이터 다시 불러오기*/   
    public void userSelectAll(DefaultTableModel model) {
       
       
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
       
        try {
            con = getConn();
            String sql = "select * from pregunta order by name asc";
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
           
            // DefaultTableModel에 있는 데이터 지우기
            for (int i = 0; i < model.getRowCount();) {
                model.removeRow(0);
            }
 
            while (rs.next()) {
                Object data[] = { rs.getInt(1), rs.getString(2),
                        rs.getString(3), rs.getString(4),
                       rs.getString(5),
                        rs.getString(6),
                        rs.getString(7)};
 
                model.addRow(data);                
            }
 
        } catch (SQLException e) {
            System.out.println(e + "=> userSelectAll fallo");
        } finally{
           
            if(rs!=null)
                try {
                    rs.close();
                } catch (SQLException e2) {
                    // TODO Auto-generated catch block
                    e2.printStackTrace();
                }
            if(ps!=null)
                try {
                    ps.close();
                } catch (SQLException e1) {
                    // TODO Auto-generated catch block
                    e1.printStackTrace();
                }
            if(con!=null)
                try {
                    con.close();
                } catch (SQLException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
        }
    }
}
 